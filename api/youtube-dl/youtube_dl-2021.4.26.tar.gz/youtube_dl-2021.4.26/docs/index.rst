Welcome to youtube-dl's documentation!
======================================

*youtube-dl* is a command-line program to download videos from YouTube.com and more sites.
It can also be used in Python code.

Developer guide
---------------

This section contains information for using *youtube-dl* from Python programs.

.. toctree::
    :maxdepth: 2

    module_guide

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

